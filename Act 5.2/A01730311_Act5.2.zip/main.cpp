//Salvador Alejandro Gaytán Ibáñez   A01730311
//Victor Alfonzo Mancera Osorio   A01733749
//Daniel Munive Meneses A01734205
#include <iostream>
#include <queue>
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <algorithm>
#include <bits/stdc++.h>
#include <iomanip>

using namespace std;


class ObjetoIP {
public:
    string dominio; //LLave

    int numeroAccesos;
    int numeroConexiones;
    bool visitado;

    vector<string> conexiones;
    vector<string> dominioSeparado;



    ObjetoIP(){
        dominio = "";
        numeroAccesos = -1;
        numeroConexiones = -1;
    }

    ObjetoIP(string Udominio, int Uaccesos, int Uconexiones){
        dominio = Udominio;
        numeroAccesos = Uaccesos;
        numeroConexiones = Uconexiones;
    }

    void addConexion(string host){
        string completa = dominio + host;
        conexiones.push_back(completa);
    }


    //TODO: MODIFICAR PARA ASCII
    int llaveNumerica(int totalCasillas){
        int total = 0;

        for(char letra : dominio){
            if(letra != '.'){
                total+=int(letra);
            }
        }
        int final = total % totalCasillas;
        return final;
    }

    void eliminar(){
        vector<string> nuevoVector;

        dominio = "";
        numeroAccesos = -1;
        numeroConexiones = -1;
        conexiones = nuevoVector;
        dominioSeparado = nuevoVector;


    }

    void cambiar(int a, int b){//metodo sort del Bubble Sort
       string Temp=conexiones[a];
       conexiones[a]=conexiones[b];
       conexiones[b]=Temp;
    }
    void imprimir(){//Metodo que Imprime la informacion de los ipNumeros
      //Imprimir Datos basicos
        cout<<dominio<<endl;
        cout<<numeroAccesos<<endl;
        cout<<numeroConexiones<<endl;
        //Inicializar variables para bubble sort de los datos
        string conexionesOrdenadas[conexiones.size()];
        int Puntos = 0;
        string Num1strg="";
        string Num2strg="";
        string Num3strg="";
        string Num4strg="";
        int Num1;
        int Num2;
        int Num3;
        int Num4;
        int Sig;
        string Actual;
        string Actual2;
        int Puntos2=0;
        for(int i = 0; i < conexiones.size(); i++){//metodo Bubble Sort O(N) de las IPS
            Actual=conexiones[i];
            for(int j=0;j<Actual.size();j++){//Ciclo secundario de Bubbke sort
              //remover puntos de las ip y conseguir los valores a comparar
              if(Actual[j]=='.'){
                Puntos++;
              }
              if(Puntos==2 && Actual[j]!='.'){
                Num1strg=Num1strg+Actual[j];
              }
              if(Puntos==3 && Actual[j]!='.'){
                Num2strg=Num2strg+Actual[j];
              }
            }
            //convertir de string a int los valores encontrados sin ip
            Num1=stoi(Num1strg);
            Num2=stoi(Num2strg);
            Num1strg="";
            Num2strg="";
            Puntos=0;
            for(int k=0;k<conexiones.size();k++){//segundo recorrido para obtener los siguientes valores a comparar
                Actual2=conexiones[k];
                for(int l=0;l<Actual2.size();l++){
                  if(Actual2[l]=='.'){
                    Puntos2++;
                  }
                  if(Puntos2==2 && Actual2[l]!='.'){
                    Num3strg=Num3strg+Actual2[l];
                  }
                  if(Puntos2==3 && Actual2[l]!='.'){
                    Num4strg=Num4strg+Actual2[l];
                  }
                }
                Num3=stoi(Num3strg);
                Num4=stoi(Num4strg);
                Num3strg="";
                Num4strg="";
                Puntos2=0;
                if(Num1>Num3){//condicionales de bubble sort
                  cambiar(i,k);//metodo sort
                }
                if(Num1==Num3 && Num2>Num4){//condicionales de bubble sort
                  cambiar(i, k);
                }
            }
        }
        for(int i=conexiones.size()-1;i>=0;i--){//imprimir de manera ascendente el array ordenado
          cout<<conexiones[i]<<endl;
        }

    }


};


//Clase ara la hashTable
class HashTable {
private:
    //Definimos el tamaño de la lista
    int hashGroups;
    //Creamos un arreglo de punteros
    vector<ObjetoIP>miTabla;

public:

    //AL crearla, la inicializamos
    HashTable(int size){
        hashGroups = size;
        inicializarTabla();
    }

    //Establecemos todas las casillas con auitomoviles vacios
    //COMPLEJIDAD: O(n)
    void inicializarTabla(){
        for(int i = 0; i < hashGroups; i++){
            ObjetoIP enBlanco = ObjetoIP();
            miTabla.push_back(enBlanco) ;
        }
    }

    //Metodo que determina si mi hash está vacía
    //COMPLEJIDAD (O(n))
    bool estaVacia(){
        int total = 0;
        for(ObjetoIP elemento : miTabla){
            if(elemento.numeroAccesos != -1){
                total+=1;
                return false;
            }
        }

        return true;
    }


    int HASH(string llave){
        int total = 0;

        for(char letra : llave){
            if(letra != '.'){
                total+=int(letra);
            }
        }
        int final = total % hashGroups;
        return final;
    }



    //Método que se encarga de insertar datos
    //COmplejidad O(n)

    int insert(string dominio, int accesos, int conexiones, vector<string> misConexiones){
        int flag =0;
        ObjetoIP dato  = ObjetoIP(dominio, accesos, conexiones);

        for(string conexion : misConexiones){
            dato.addConexion(conexion);
        }

        int posicion = dato.llaveNumerica(hashGroups);

        ObjetoIP elemento = miTabla[posicion];

        //SI mi elemento no esta vacío
        if(elemento.numeroAccesos != -1){
            //Establecemos que fue visitado
            elemento.visitado = true;

            //Realizamos un ciclo que recorre el resto de las casillas en busca de una vacía
            for(int i = posicion+1; i < hashGroups; i++){
                if(miTabla[i].numeroConexiones == -1){ //SI está vacía..
                    miTabla[i] = dato; //Le colocamos el dato
                    break;
                }

                //Reiniciar tabla
                else if(i == hashGroups-1){ //SI llegamos al finaliza, inicializamos el contador
                    i = -1;
                }

                else if( i == posicion){ //Si volvemos a llegar a la misma pos, entonces no hay espacios disponibles
                  flag++;
                    break;
                }
            }
        }
        else{
            miTabla[posicion] = dato; //SI esta vacía, entonces colocamos el dato
        }
        return flag;
    }

    void eliminar(string llave){
        int posicion = HASH(llave);

        if(!estaVacia()){ //Si no está vacía...
            if(miTabla[posicion].numeroConexiones != -1){ //Si la posicion es diferente de nulo, entonces eliminamos
                miTabla[posicion].eliminar();
            }

            else{
                if(miTabla[posicion].visitado){ //SI la posicion se encuentra visitada
                    for(int i = posicion+1; i < hashGroups; i++){ //Buscamos la casilla a la que corresponda la llave
                        if(miTabla[i].dominio == llave){
                            miTabla[i].eliminar();
                        }
                        else if(i == hashGroups-1){
                            i = 0;
                        }

                        else if( i == posicion){
                            break;
                        }
                    }
                }
            }
        }

    }


    //Búsqueda (Complejidad O(n))
    void search(string llave){

        int posicion = HASH(llave);

        if(miTabla[posicion].numeroConexiones != -1 && miTabla[posicion].dominio == llave){
            //cout<<posicion<<endl;
            miTabla[posicion].imprimir();
        }

        else{
            if(miTabla[posicion].visitado){
                for(int i = posicion+1; i < hashGroups; i++){
                    if(miTabla[i].dominio == llave){
                        //cout<<posicion<<endl;
                        miTabla[i].imprimir();
                    }
                    else if(i == hashGroups-1){
                        i = -1;
                    }

                    else if( i == posicion){
                        break;
                    }
                }
            }
        }
    }

    void print(){
        for(int i = 0; i<hashGroups; i++){
            cout<<i;
            miTabla[i].imprimir();
        }
    }
};



//Objeto petición que se encarga de almacena en propiedades separadas cada uno de los
//valores inmersos en  las notificaciones de la bitacora
class Peticion {
private:
//Separamos entonces los meses, dias, horas, la ip  y el mensaje
    std::string mes;
    std::string dia;
    std::string hora;
    std::string ip;
    std::string mensaje;


    //Creamos un diccionario para poder relacionar el mes con su respectivo número
    std::map<std::string, std::string> clavesMes = {{"Jan", "01"}, {"Feb", "02"},  {"Mar", "03"},  {"Apr", "04"},  {"May", "05"},  {"Jun", "06"},  {"Jul", "07"},  {"Aug", "08"}, {"Sep", "09"}, {"Oct", "10"}, {"Nov", "11"}, {"Dec", "12"}};


public:
    vector<string> ipNumeros;

//Establecemos los constructores
    explicit Peticion();
    explicit Peticion(std::string Umes, std::string Udia, std::string Uhora, std::string Uip, std::string Umensaje );

//Función que transformará toda la fecha en unidad unix
    long int obtenerUnit();

//Métodos que imprimen los valores más relevantes
    void imprimir();
    std::string imprimirarchivo();

    void separarNumerosIp();

//Métoodo que se encarga de regresar el dia junto con el mes de la petición
    std::string diaMes();


    string ObtenerElementoIP(string opcion);
};

Peticion::Peticion(): mes("1"), dia("1"), hora("00:00:00"), ip(""), mensaje("Ningnuno"){};
Peticion::Peticion(std::string Umes, std::string Udia, std::string Uhora, std::string Uip, std::string Umensaje ): mes(Umes), dia(Udia), hora(Uhora), ip(Uip), mensaje(Umensaje){};


void Peticion::imprimir(){
    std::string texto = mes + " " + dia + " " + hora + " " + ip + " " + mensaje;

    std::cout<<texto<<"\n" ;
}
std::string Peticion::imprimirarchivo(){
    std::string texto = mes + " " + dia + " " + hora + " " + ip + " " + mensaje+"\n";

    return texto;
}

std::string Peticion::diaMes() {

    std::string valor = mes + " " + dia;

    return valor;
}




//Para transfomrar a unidad de tiempo "Unix" realizamos el siguiente método
long int Peticion::obtenerUnit(){
    std::tm t = {};
    //Establecemos el formato de la fecha, en donde por cuestiones de eficiencia,
    //establecemos el año como 1970 (Año en donde empeiza el conteo numérico)
    std::string fecha = "1970-"+clavesMes[mes]+"-"+dia+"T"+hora+"Z"; //Original "1970-11-04T23:23:01Z"

    //Creamos un stringstream que almacenara cada elemento de la fecha
    std::istringstream ss(fecha);
    long int valor;
    //Si cada elemento corresponde al formato año, mes dia hora minuto y segundo
    if (ss >> std::get_time(&t, "%Y-%m-%dT%H:%M:%S"))
    {
        //Regresamos el valor numerico haciendo uso de "mktime"
        return valor = std::mktime(&t);
    }
        //En caso de que ese no sea el formato, entonces...
    else
    {
        std::cout << "Formato inválido\n";
    }
    return 0;
}


//Método que se encarga de separar los numeros que conforman la ip con la finalidad de comparalos con otras ip's
void Peticion::separarNumerosIp(){
    string parteIp =""; //Establecemos un string que almacenrá cada parte de la ip
    //COMPLEJIDAD: O(c) donde c es el numero de caracteres en la IP
    for(char& c : ip) { //Recorremos cada caracter del string
        if(c != '.' && c != ':' ){ //Si no encontramos : o .
            parteIp+=c; //Entonces añadimos ese caracter a nuestro "parteIp"
        }
            //En caso de que encontremos un punto o :
        else{
            //Añadimos a nuestro vector el numero que logramos conformar
            ipNumeros.push_back(parteIp);
            //Reestablecemos nuestra variable que almacena las partes de la ip
            parteIp = "";
        }
    }
    //Finalmete, añadimos la ultima parte de la ip
    ipNumeros.push_back(parteIp);
}


string Peticion::ObtenerElementoIP(string opcion){
    separarNumerosIp();
    string valorCompleto = "";
    if(opcion == "red"){
        valorCompleto = ipNumeros[0]+".";
        valorCompleto += ipNumeros[1];
    }
    else{
        valorCompleto = ipNumeros[2]+".";
        valorCompleto += ipNumeros[3];

    }

    return valorCompleto;
}




//Clase destinada a crear nodos que representen el camino
class NodoHost {
public:
    //Poseen un valor
    string valor;
    //Un puntero al siguiiente nodo
    NodoHost* nodoSiguiente;

    //Vector con todos los mensajes de error de este registro
    vector<string>misMensajes;

    //Constructor
    NodoHost(string nuevoValor){
        valor = nuevoValor;
        nodoSiguiente = nullptr;
    }

    NodoHost(){
        valor = "";
        nodoSiguiente = nullptr;
    }

    void addMensaje(string mensaje){
        misMensajes.push_back(mensaje);
    }


    void imprimirMensajes(){
        cout<<"     ***********"<<endl;
        cout<<"Maximo ocurrencias: "<<misMensajes.size()<<endl;
        for(string mensaje : misMensajes){
            cout<<"      "<<mensaje<<endl;
        }
        cout<<"     ***********"<<endl;

    }

//Cuenta cada una de las ocurrencias
    int contarOcurrencias(){
        int numberOcurrencias;
        numberOcurrencias = misMensajes.size();
        return numberOcurrencias;
    }


};


//Nodo cabeza o base del cual se parte del camino (NodoAzul)
class NodoRed{
public:
    //Posee un valor
    string valor;
    //Un nodo rojo inicial
    NodoHost* nodoRojo;
    //Un nodo azul con el que se comunica con el resto de nodos
    NodoRed* nodoAzul;

    //Constructor
    NodoRed(string miValor, NodoHost* miNodoCamino, NodoRed* miNodoBase){
        valor = miValor;
        nodoRojo = miNodoCamino;
        nodoAzul = miNodoBase;
    }

    NodoRed(){
        valor = "";
        nodoRojo = nullptr;
        nodoAzul = nullptr;
    }

    //Método que se encarga de añadir un nodo rojo.
    void addNodoRojo(NodoHost* nuevoNodo, string mensaje){
        bool repetido = false;
        //Si se posee un nodo rojo
        if(nodoRojo != nullptr){
            //Los recorremos
            NodoHost* nodoActual = nodoRojo;
            if(nodoActual->valor == nuevoNodo->valor){
                repetido = true;
            }
            while(nodoActual->nodoSiguiente != nullptr){
                if(nodoActual->valor != nuevoNodo->valor){
                    nodoActual = nodoActual->nodoSiguiente;
                }
                else{
                    repetido = true;
                    break;
                }
            }
            //Una vez que llegamos al último, establecemos que su siguiente nodo será el nuevo nodo

            if(!repetido){
                nodoActual->nodoSiguiente = nuevoNodo;
            }
            else{
                nodoActual->addMensaje(mensaje);
            }

        }
            //En caso de que no tengamos alguno, decimos que el nodo rojo base de este nodo azul, será el nuevo nodo
        else{
            nodoRojo = nuevoNodo;
        }

    }

    void addNodoAzul(NodoRed* nodoBase){
        nodoAzul = nodoBase;
    }

    int obtenerGrado(){
        int grado = 0;
        NodoHost* nodoActual = nodoRojo;
        while (nodoActual != nullptr){
            grado++;
            nodoActual = nodoActual->nodoSiguiente;
        }

        return grado;
    }

    //Complejidad O(n)
    //Busca el Grado mayor
    int maxRed(){
        NodoHost* nodoActual = nodoRojo;
        int gradoMax=0;
        int grd=0;
        if(nodoActual == nullptr){
            cout<<" FIN "<<endl;
        }
        else{
            grd=obtenerGrado();
            if (grd > gradoMax){
                gradoMax = grd;
            } else {
                gradoMax = gradoMax;
            }
        }
        return gradoMax;
    }

    //Complejidad O(n)
    //Imprime el valor Red que cumpla con el grado maximo
    void imprimirMaxRed(int gradoMax){
        NodoHost* nodoMax = nodoRojo;

        if(nodoMax == nullptr){
            cout<<" "<<valor<<endl;
        }
        else{
            if (obtenerGrado() == gradoMax) {
                cout<<valor<<endl;
            }
        }

        while(nodoMax != nullptr){

            nodoMax = nodoMax->nodoSiguiente;
        }

    }

    void imprimirConexiones(){
        NodoHost* nodoActual = nodoRojo;

        if(nodoActual == nullptr){
            cout<<"Ta solito "<<valor<<endl;
        }
        else{
            cout<<valor<<endl;
            cout<<"Grado: "<<obtenerGrado()<<endl;

        }
        cout<<"------------------------"<<endl;
        while(nodoActual != nullptr){
            cout<<"   "<<nodoActual->valor<<endl;
            nodoActual->imprimirMensajes();
            nodoActual = nodoActual->nodoSiguiente;
        }
        cout<<"------------------------"<<endl;
        cout<<"\n";
        cout<<"\n";
    }

    int numAccesos(){
        NodoHost* nodoActual = nodoRojo;
        int accesos=0;
        int sumAccesos=0;
        while(nodoActual != nullptr){
            accesos=nodoActual->contarOcurrencias();
            nodoActual = nodoActual->nodoSiguiente;
            sumAccesos= sumAccesos + accesos;
        }

        return sumAccesos;
    }


    std::vector<string> datos(){
      string datos;
        std::vector <string> temp_arr;
        NodoHost* nodoActual = nodoRojo;
        while(nodoActual != nullptr){
            datos = "." + nodoActual->valor;
            temp_arr.push_back(datos);
            nodoActual = nodoActual->nodoSiguiente;
        }

      return temp_arr;
    }

    string redes(){
        NodoHost* nodoActual = nodoRojo;
        string red;
        red = valor;
      return valor;
    }

};

HashTable miTabla = HashTable(32749);

//Metodo que se encarga de leer los datos por parte del txr
void lecturaDatos(){

    NodoRed* nodoRaiz = new NodoRed();
    //Creamos el objeto del archivo a arbitraria
    ifstream archivo;
    //Generamos un vector de objetos peticiones
    vector<Peticion> misPeticiones;
    //Abrimos el archivo de nombre "bitácota.txt"
    archivo.open("bitacora2.txt");
    //Si el archivo se encuentra abierto...
    if(archivo.is_open()){
        //Creamos una variable que alamcenara cada lista
        std::string linea;
        //Ejecutamos un ciclo que recorre todas las lineas del archivo
        while (getline(archivo, linea)){
            //Por cada linea, creamos un "separador" de tipo "stringstream"
            std::stringstream separador(linea);
            //Creamos una variable que alamcenará cada palabra
            std::string palabra;
            //Un vector de palabras separadas de cada línea
            vector<string> palabras;
            //Indice que indica el numero de palabra que estamos analizando
            int indice = 0;

            //Ciclo que recorre cada una de las palabras
            while(separador >> palabra){
                //Si el indice es igual o mayor a 5, significa que estamos en el mensaje de error
                if(indice >= 5){
                    //Lo anexamos en el indice 4
                    palabras[indice-1] += " " + palabra;
                }
                    //De cualquier otra forma, significa que estamos en las palabras anteriores
                else{
                    //Las añadimo al vector y aumentamos el indidce para que siga almacenando las palabras en espacios distintos del vector.
                    palabras.push_back(palabra);
                    indice++;
                }
            }

            //Creamos el objeto peticion, brindando como argumentos cada elemento de mi vector de palabras
            auto objeto = Peticion(palabras[0], palabras[1], palabras[2], palabras[3], palabras[4]);

            //Obtengo los dos enteros del host
            string valorHost = objeto.ObtenerElementoIP("host");
            //Creo un objeto nuevo de tipo nodoHost
            NodoHost* nuevoNodoHost = new NodoHost(valorHost);
            //le asigno el mensaje en cuestión
            nuevoNodoHost->addMensaje(palabras[4]);

            //Si el nodo raiz no tiene nada...
            if(nodoRaiz->valor == ""){
                //Creo un nuevo nodo red
                NodoRed* nuevoNodoRed = new NodoRed(objeto.ObtenerElementoIP("red"), nuevoNodoHost, nullptr );
                //Establezco que el nodo raiz sera el nuevo nodo red
                nodoRaiz = nuevoNodoRed;
            }
                //Si mi raiz no está vacía
            else{
                //Obtengo los dos enteros de la red
                string valorRed =  objeto.ObtenerElementoIP("red");
                //Establezco una bandera que me avisará si el valor de este nodo ya se encuentra en la lista
                bool nodoEnLista = false;

                //Obtengo el nodo actual
                NodoRed* nodoActual = nodoRaiz;
                //Recorro todos los nodos (COMPLEJIDAD: O(n))
                while(nodoActual->nodoAzul != nullptr){
                    //Si algun nodo ya posee el valor del nuevo nodo...
                    if(nodoActual->valor == valorRed){
                        //A ese nodo (Al de la lista) le añado su nodo rojo
                        nodoActual->addNodoRojo(nuevoNodoHost, palabras[4]);
                        //Establezco que está en la lista
                        nodoEnLista = true;
                    }
                    //De lo contrario, seguimos recorriendo
                    nodoActual = nodoActual->nodoAzul;
                }


                //Si el nodo noe estaba en la lista
                if(nodoEnLista == false){
                    //Verificamos de nueva cuenta que el nodo no sea igual al valor
                    if(nodoActual->valor == valorRed){
                        //Si el nodo actual tiene el mismo valor, entonces a ese nodo le añado su nodo rojo
                        nodoActual->addNodoRojo(nuevoNodoHost, palabras[4]);
                    }
                    else{ //Si el nodo de la lista no es el mismo...
                        //Creo el nuevo nodo red
                        NodoRed* nuevoNodoRed = new NodoRed(objeto.ObtenerElementoIP("red"), nuevoNodoHost, nullptr );
                        //Lo añado a los azules
                        nodoActual->addNodoAzul(nuevoNodoRed);
                    }

                }

            }

            //Añadimos nuestro objeto al arreglo de peticiones
            misPeticiones.push_back(objeto);
        }
    }
    else {
        std::cout<<"Error! No se pudo abrir el archivo";
    }

    NodoRed* NodoActual;
    NodoActual = nodoRaiz;

//Lee cada uno de las Conexiones 0(n)
    std::vector<int> numConex;
    int conex;
    NodoActual = nodoRaiz;
    while (NodoActual != nullptr){
        conex=NodoActual->maxRed();
        //std::cout << "Conexiones de Red: "<< conex << '\n';
        numConex.push_back(conex);
        NodoActual = NodoActual->nodoAzul;
    }

//Lee cada uno de las Accesos 0(n)
    std::vector<int> numAcces;
    int accesos;
    NodoActual = nodoRaiz;
    while (NodoActual != nullptr){
            accesos=NodoActual->numAccesos();
            numAcces.push_back(accesos);
        NodoActual = NodoActual->nodoAzul;
    }

    NodoActual = nodoRaiz;
    vector<string>prueba;
    prueba=NodoActual->datos();

//Lee cada uno de las Redes 0(n)
    std::vector<string> redes;
    string temp;
    NodoActual = nodoRaiz;
    while (NodoActual != nullptr){
            temp=NodoActual->redes();
            redes.push_back(temp);
        NodoActual = NodoActual->nodoAzul;
    }

//va insretando en mi tabla hash los datos
      NodoActual = nodoRaiz;
      std::vector<string> conexiones;
      std::vector<string> v;
      int count=0;
      while (NodoActual != nullptr && count==0){
                conexiones = NodoActual->datos();
                count = miTabla.insert(NodoActual->redes(), NodoActual->numAccesos(), NodoActual->maxRed(), NodoActual->datos());
          NodoActual = NodoActual->nodoAzul;
      }
      if (count != 0){
        std::cout << "Tabla llena, imposible meter más datos" << '\n';
      }

};


int main() {

    lecturaDatos();
    //leer el imput del usuario
    int NumDominios;
    cin>>NumDominios;
    string ArrayDominios[NumDominios];
    string DomTemp;
    for(int i=0;i<NumDominios;i++){//llenar el array con las redes a buscar
        cin>>DomTemp;
        ArrayDominios[i]=DomTemp;
    }
    for(int i=0;i<NumDominios;i++){//buscar cada red con el metodo search
      miTabla.search(ArrayDominios[i]);
      cout<<endl;
    }

}
