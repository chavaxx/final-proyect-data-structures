#include <iostream>
#include <queue>
#include <bits/stdc++.h>
#include <iomanip>
#include <map>
#include <string>
#include <vector>
using namespace std;

// Víctor Alfonso Mancera Osorio  A01733749
// Salvador Alejandro Gaytan Ibañez A01730311
// Daniel Munive Meneses A01734205

//Objeto petición que se encarga de almacena en propiedades separadas cada uno de los
//valores inmersos en  las notificaciones de la bitacora

class Peticion {
private:
//Separamos entonces los meses, dias, horas, la ip  y el mensaje
    std::string mes;
    std::string dia;
    std::string hora;
    std::string ip;
    std::string mensaje;


    //Creamos un diccionario para poder relacionar el mes con su respectivo número
    std::map<std::string, std::string> clavesMes = {{"Jan", "01"}, {"Feb", "02"},  {"Mar", "03"},  {"Apr", "04"},  {"May", "05"},  {"Jun", "06"},  {"Jul", "07"},  {"Aug", "08"}, {"Sep", "09"}, {"Oct", "10"}, {"Nov", "11"}, {"Dec", "12"}};


public:
    vector<int> ipNumeros;

//Establecemos los constructores
    explicit Peticion();
    explicit Peticion(std::string Umes, std::string Udia, std::string Uhora, std::string Uip, std::string Umensaje );

//Función que transformará toda la fecha en unidad unix
    long int obtenerUnit();

//Métodos que imprimen los valores más relevantes
    void imprimir();
    std::string imprimirarchivo();

    void separarNumerosIp();

//Métoodo que se encarga de regresar el dia junto con el mes de la petición
    std::string diaMes();


};

Peticion::Peticion(): mes("1"), dia("1"), hora("00:00:00"), ip(""), mensaje("Ninguno"){};
Peticion::Peticion(std::string Umes, std::string Udia, std::string Uhora, std::string Uip, std::string Umensaje ): mes(Umes), dia(Udia), hora(Uhora), ip(Uip), mensaje(Umensaje){};


void Peticion::imprimir(){
    std::string texto = mes + " " + dia + " " + hora + " " + ip + " " + mensaje;

    std::cout<<texto<<"\n" ;
}
std::string Peticion::imprimirarchivo(){
    std::string texto = mes + " " + dia + " " + hora + " " + ip + " " + mensaje+"\n";

    return texto;
}

std::string Peticion::diaMes() {

    std::string valor = mes + " " + dia;

    return valor;
}

//Para transfomrar a unidad de tiempo "Unix" realizamos el siguiente método
long int Peticion::obtenerUnit(){
    std::tm t = {};
    //Establecemos el formato de la fecha, en donde por cuestiones de eficiencia,
    //establecemos el año como 1970 (Año en donde empeiza el conteo numérico)
    std::string fecha = "1970-"+clavesMes[mes]+"-"+dia+"T"+hora+"Z"; //Original "1970-11-04T23:23:01Z"

    //Creamos un stringstream que almacenara cada elemento de la fecha
    std::istringstream ss(fecha);
    long int valor;
    //Si cada elemento corresponde al formato año, mes dia hora minuto y segundo
    if (ss >> std::get_time(&t, "%Y-%m-%dT%H:%M:%S"))
    {
        //Regresamos el valor numerico haciendo uso de "mktime"
        return valor = std::mktime(&t);
    }
        //En caso de que ese no sea el formato, entonces...
    else
    {
        std::cout << "Formato inválido\n";
    }
    return 0;
}


//Método que se encarga de separar los numeros que conforman la ip con la finalidad de comparalos con otras ip's
void Peticion::separarNumerosIp(){
    string parteIp =" "; //Establecemos un string que almacenrá cada parte de la ip
    //COMPLEJIDAD: O(c) donde c es el numero de caracteres en la IP
    for(char& c : ip) { //Recorremos cada caracter del string
        if(c != ':' && c != '.' ){ //Si no encontramos : o .
            parteIp+=c; //Entonces añadimos ese caracter a nuestro "parteIp"
        }
            //En caso de que encontremos un punto o :
        else{
            //Añadimos a nuestro vector el numero que logramos conformar
            ipNumeros.push_back(stoi(parteIp));
            //Reestablecemos nuestra variable que almacena las partes de la ip
            parteIp = "";
        }
    }
    //Finalmete, añadimos la ultima parte de la ip
    ipNumeros.push_back(stoi(parteIp));
}



class BST {

    struct node {
        Peticion data;
        node* left;
        node* right;
    };

    node* root;

    node* makeEmpty(node* t) {
        if(t == NULL)
            return NULL;
        {
            makeEmpty(t->left);
            makeEmpty(t->right);
            delete t;
        }
        return NULL;
    }

    node* insert(Peticion x, node* t){
        if(t == NULL){
            t = new node;
            t->data = x;
            t->left = t->right = NULL;
        }

        else {
            int indice = 0;
            bool menor =false;
            while(true){
                //Si el numero en el indice en cuestión es mayor al de la raiz...

                if(x.ipNumeros[indice] >t->data.ipNumeros[indice]){
                    //Rompemos
                    break;
                }
                //Si es menor...
                if(x.ipNumeros[indice] < t->data.ipNumeros[indice]){
                    //Establecemos que menor es igual a verdadero
                    menor = true;
                    //Salimos del ciclo
                    break;
                }

                //Si el indice es igual al total de elementos en la ip...
                if(indice == x.ipNumeros.size()-1){
                    //Comparamos los tiempos...
                    //Si es menor, entoces...
                    if(x.obtenerUnit() < t->data.obtenerUnit()){
                        menor = true;
                    }
                    //Salimos
                    break;

                }

                //En cada iteración aumentamos el índice
                indice++;
            }

            if(menor)
                t->left = insert(x, t->left);
            else if(!menor)
                t->right = insert(x, t->right);

            return t;

        }
        return t;
    }

    node* findMax(node* t) {
        if(t == NULL)
            return NULL;
        else if(t->right == NULL)
            return t;
        else
            return findMax(t->right);
    }



    void inorder(node* t) {

        //vector<Peticion> miVector;   vector<Peticion>
        if(t == NULL){

            //return miVector;
            return;
        }

        inorder(t->left);
        //miVector.push_back(t->data);
        //t->data.imprimir();
        inorder(t->right);

        //return miVector;

        return;
    }
    //funcion que busca el elemento n del arbol, O(n)
    void NthInorder(node* t, int n)  {
        node* temp = t;
        static int count = 0;
        if (temp == NULL)
            return;

        if (count <= n) {

            // Revisa el nodo de la izquierda
            NthInorder(temp->left, n);
            count++;

            // Cuando encuntra que count == n imprime el nodo en esa ubicacion
            if (count == n) {
                count = 0;
                temp->data.imprimir();
                return;

            }

            //Revisa el nodo de la derecha
            NthInorder(temp->right, n);
        }
    }

public:
    BST() {
        root = NULL;
    }

    ~BST() {
        root = makeEmpty(root);
    }

    void insert(Peticion x) {
        root = insert(x, root);
    }


    void display(int count) {
        NthInorder(root, count);
    }


};

//Metodo que se encarga de leer los datos por parte del txr
void lecturaDatos(){
    BST miArbol;
    int contador=0;
    //Creamos el objeto del archivo a arbitraria
    ifstream archivo;
    //Generamos un vector de objetos peticiones
    vector<Peticion> misPeticiones;
    //Abrimos el archivo de nombre "bitácota.txt"
    archivo.open("bitacora.txt");
    //Si el archivo se encuentra abierto...
    if(archivo.is_open()){
        //Creamos una variable que alamcenara cada lista
        std::string linea;
        //Ejecutamos un ciclo que recorre todas las lineas del archivo
        while (getline(archivo, linea)){
            //Por cada linea, creamos un "separador" de tipo "stringstream"
            std::stringstream separador(linea);
            //Creamos una variable que alamcenará cada palabra
            std::string palabra;
            //Un vector de palabras separadas de cada línea
            vector<string> palabras;
            //Indice que indica el numero de palabra que estamos analizando
            int indice = 0;

            //Ciclo que recorre cada una de las palabras
            while(separador >> palabra){
                //Si el indice es igual o mayor a 5, significa que estamos en el mensaje de error
                if(indice >= 5){
                    //Lo anexamos en el indice 4
                    palabras[indice-1] += " " + palabra;
                }
                    //De cualquier otra forma, significa que estamos en las palabras anteriores
                else{
                    //Las añadimo al vector y aumentamos el indidce para que siga almacenando las palabras en espacios distintos del vector.
                    palabras.push_back(palabra);
                    indice++;
                }
            }

            //Creamos el objeto peticion, brindando como argumentos cada elemento de mi vector de palabras
            auto objeto = Peticion(palabras[0], palabras[1], palabras[2], palabras[3], palabras[4]);
            //Ejecutamos el método que se encarga de separar los números de la ip
            objeto.separarNumerosIp();
            //Añadimos nuestro objeto al arreglo de peticiones
            misPeticiones.push_back(objeto);

            miArbol.insert(objeto);
            contador++;
        }

    }
    else {
        std::cout<<"Error! No se pudo abrir el archivo";
    }
        for(int i = contador;i > contador-5; i--){
        miArbol.display(i);
        }

}




int main() {
    //ejecucion del metodo principal del programa
    lecturaDatos();

    return 0;
}