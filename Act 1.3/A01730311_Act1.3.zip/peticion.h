//
// Created by victo on 11/09/2020.
#include <iostream>
#include <sstream>
#include <locale>
#include <iomanip>
#include <map>
#include <string>

//Objeto petición que se encarga de almacena en propiedades separadas cada uno de los 
//valores inmersos en  las notificaciones de la bitacora
class Peticion {
private:
//Separamos entonces los meses, dias, horas, la ip  y el mensaje
    std::string mes;
    std::string dia;
    std::string hora;
    std::string ip;
    std::string mensaje;

    //Creamos un diccionario para poder relacionar el mes con su respectivo número
    std::map<std::string, std::string> clavesMes =
            {{"Jan", "01"}, {"Feb", "02"},  {"Mar", "03"},  {"Apr", "04"},  {"May", "05"},  {"Jun", "06"},  {"Jul", "07"},  {"Aug", "08"}, {"Sep", "09"}, {"Oct", "10"}, {"Nov", "11"}, {"Dec", "12"}};


public:

//Establecemos los constructores
    explicit Peticion();
    explicit Peticion(std::string Umes, std::string Udia, std::string Uhora, std::string Uip, std::string Umensaje );

//Función que transformará toda la fecha en unidad unix
    long int obtenerUnit();

//Métodos que imprimen los valores más relevantes
    void imprimir();
    std::string imprimirarchivo();

//Métoodo que se encarga de regresar el dia junto con el mes de la petición
    std::string diaMes();


};

Peticion::Peticion(): mes("1"), dia("1"), hora("00:00:00"), ip(""), mensaje("Ningnuno"){};
Peticion::Peticion(std::string Umes, std::string Udia, std::string Uhora, std::string Uip, std::string Umensaje ): mes(Umes), dia(Udia), hora(Uhora), ip(Uip), mensaje(Umensaje){};


void Peticion::imprimir(){
    std::string texto = mes + " " + dia + " " + hora + " " + ip + " " + mensaje;

    std::cout<<texto<<"\n" ;
}
std::string Peticion::imprimirarchivo(){
    std::string texto = mes + " " + dia + " " + hora + " " + ip + " " + mensaje+"\n";

    return texto;
}

std::string Peticion::diaMes() {

    std::string valor = mes + " " + dia;

    return valor;
}

//Para transfomrar a unidad de tiempo "Unix" realizamos el siguiente método
long int Peticion::obtenerUnit(){
    std::tm t = {};
    //Establecemos el formato de la fecha, en donde por cuestiones de eficiencia, 
    //establecemos el año como 1970 (Año en donde empeiza el conteo numérico)
    std::string fecha = "1970-"+clavesMes[mes]+"-"+dia+"T"+hora+"Z"; //Original "1970-11-04T23:23:01Z"

    //Creamos un stringstream que almacenara cada elemento de la fecha
    std::istringstream ss(fecha);
    long int valor;
  //Si cada elemento corresponde al formato año, mes dia hora minuto y segundo
    if (ss >> std::get_time(&t, "%Y-%m-%dT%H:%M:%S"))
    {
      //Regresamos el valor numerico haciendo uso de "mktime"
        return valor = std::mktime(&t);
    }
    //En caso de que ese no sea el formato, entonces...
    else
    {
        std::cout << "Formato inválido\n";
    }
    return 0;
}


#ifndef UNTITLED1_PETICION_H
#define UNTITLED1_PETICION_H

#endif //UNTITLED1_PETICION_H
