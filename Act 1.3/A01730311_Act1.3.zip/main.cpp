/*
Autores y matriculas:
-Sahid Emmanuel Rosas Maas A01734211
-Salvador Alejandro Gaytán Ibáñez A01730311
-Victor Alfonso Mancera Osorio A01733749

Fecha de creacion:11/09/2020
Ultima modificaion:12/09/2020
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "string.h"
#include "peticion.h"
using namespace std;


//Método de ordenamiento por merge (Complejidad O(nlogn))
void mergeSort(vector<Peticion>&inferior, vector<Peticion>& superior, vector<Peticion>& miVector)
{
    int nL = inferior.size();
    int nR = superior.size();
    int i = 0, j = 0, k = 0;

    while (j < nL && k < nR)
    {

        if (inferior[j].obtenerUnit() < superior[k].obtenerUnit()) {
            miVector[i] = inferior[j];
            j++;
        }
        else {
            miVector[i] = superior[k];
            k++;
        }
        i++;
    }
    while (j < nL) {
        miVector[i] = inferior[j];
        j++; i++;
    }
    while (k < nR) {
        miVector[i] = superior[k];
        k++; i++;
    }
}

void sort(vector<Peticion> & miVector) {
    if (miVector.size() <= 1) return;

    int mid = miVector.size() / 2;
    vector<Peticion> left;
    vector<Peticion> right;

    for (size_t j = 0; j < mid;j++)
        left.push_back(miVector[j]);
    for (size_t j = 0; j < (miVector.size()) - mid; j++)
        right.push_back(miVector[mid + j]);

    sort(left);
    sort(right);
    mergeSort(left, right, miVector);
}
//funcion que busca por busqueda secuencial (O(n)) el indice del 
//valor mas pequeño de la fecha seleccionada, en caso de no 
//exista este valor, toma el siguiente valor mayor más pequeño
long int busquedainferior(vector<Peticion>&a,long int limites){
  for(long int i=0;i<a.size();i++){
    if(a[i].obtenerUnit()>=limites){
      return i;
    }
  }
  return -1;
}
/* Funcion que busca por busqueda secuencial (O(n)) el indice del
valor mas grande de la fecha dada, en caso de no encontrarlo
toma el siguiente mas pequeño*/
long int busquedasuperior(vector<Peticion>&a,long int limites){
  for(long int i=a.size()-1;i>=0;i--){
    if(a[i].obtenerUnit()<=limites){
      return i;
    }
  }
  return -1;
}
/*
La funcion solicita es de tipo void y recibe como parametro un array de tipo (long) int. 
La funcion le pide al usuario dos fechas diferentes, en ambas primero el dia y despues el mes.
Despues, transforma las fechas dadas a una medida arbitraria de tiempo basada en segundos
con el cual se clasifican las entradas. Finalmente, se añaden los segundos obtenidos al array dado.

Complejidad: O(1)
*/
void solicita(long int limites[]){
std::string mesFloor;
std::string diaFloor;

std::cin>>diaFloor; std::cin.ignore();
std::cin>>mesFloor; std::cin.ignore();

if(diaFloor.length()<2){
    diaFloor="0"+diaFloor;
}
if(mesFloor.length()<2){
    mesFloor="0"+mesFloor;
}
std::string mesCeiling;
std::string diaCeiling;

std::cin>>diaCeiling; std::cin.ignore();
std::cin>>mesCeiling; std::cin.ignore();

if(diaCeiling.length()<2){
    diaCeiling="0"+diaCeiling;
}
if(mesCeiling.length()<2){
    mesCeiling="0"+mesCeiling;
}
std::tm t1 = {};
std::tm t2 = {};

std::string fechaFloor = "1970-"+mesFloor+"-"+diaFloor+"T00:00:00Z"; 
std::string fechaCeiling = "1970-"+mesCeiling+"-"+diaCeiling+"T23:59:59Z";

std::istringstream ss1(fechaFloor);
std::istringstream ss2(fechaCeiling);

long int valorFloor;
long int valorCeiling;

if(ss1 >> std::get_time(&t1, "%Y-%m-%dT%H:%M:%S")){
   valorFloor = std::mktime(&t1);
}


if(ss2 >> std::get_time(&t2, "%Y-%m-%dT%H:%M:%S")){
  valorCeiling = std::mktime(&t2);
}


limites[0]=valorFloor;
limites[1]=valorCeiling;

}

//Metodo que se encarga de leer los datos por parte del txr
void lecturaDatos(){
    //Creamos el objeto del archivo a arbitraria
    ifstream archivo;
    //Generamos un vector de objetos peticiones
    vector<Peticion> misPeticiones;
    //Abrimos el archivo de nombre "bitácota.txt"
    archivo.open("bitacora.txt");
    //Si el archivo se encuentra abierto...
    if(archivo.is_open()){
      //Creamos una variable que alamcenara cada lista
        std::string linea;
        //Ejecutamos un ciclo que recorre todas las lineas del archivo
        while (getline(archivo, linea)){
          //Por cada linea, creamos un "separador" de tipo "stringstream"
            std::stringstream separador(linea);
            //Creamos una variable que alamcenará cada palabra
            std::string palabra;
            //Un vector de palabras separadas de cada línea
            vector<string> palabras;
            //Indice que indica el numero de palabra que estamos analizando
            int indice = 0;

            //Ciclo que recorre cada una de las palabras
            while(separador >> palabra){
              //Si el indice es igual o mayor a 5, significa que estamos en el mensaje de error
                if(indice >= 5){
                  //Lo anexamos en el indice 4
                    palabras[indice-1] += " " + palabra;
                }
                //De cualquier otra forma, significa que estamos en las palabras anteriores
                else{
                  //Las añadimo al vector y aumentamos el indidce para que siga almacenando las palabras en espacios distintos del vector. 
                    palabras.push_back(palabra);
                    indice++;
                }
            }

            //Creamos el objeto peticion, brindando como argumentos cada elemento de mi vector de palabras
            auto objeto = Peticion(palabras[0], palabras[1], palabras[2], palabras[3], palabras[4]);
            //Lo añadimos al vector de peticion
            misPeticiones.push_back(objeto);
        }
        
        //Los ordenamos a través de sort
        sort(misPeticiones);
        // exportar valores a un archivo txt
        string verout;
        verout="sortedData.txt";
        ofstream archivosalida(verout);
        for (long int i= misPeticiones.size()-1;i>=0;i--){
          archivosalida<<misPeticiones[i].imprimirarchivo();
        }  
        for(long int i = 0; i< misPeticiones.size(); i++){
            misPeticiones[i].imprimir();
        }
        
        //cout<<"Busqueda de fechas:"<<endl;
        long int limites[3];
        solicita(limites);

        long int IndiceMenor=busquedainferior(misPeticiones, limites[0]);
        if(IndiceMenor==-1){
          IndiceMenor=1;
        }
        long int IndiceMayor=busquedasuperior(misPeticiones, limites[1]);
        for(long int i=IndiceMenor;i<=IndiceMayor;i++){
          misPeticiones[i].imprimir();
        }
        //exportar valores de la busqueda a un archivo txt
        string verout2;
        verout2="Busquedas.txt";
        ofstream archivosalidab(verout2);
        for(long int i=IndiceMenor;i<=IndiceMayor;i++){
          archivosalidab<<misPeticiones[i].imprimirarchivo();
        }        


    }
    else {
        std::cout<<"Error! No se pudo abrir el archivo";
    }   
}




int main() {
  //ejecucion del metodo principal del programa
    lecturaDatos();

    return 0;
}
