/*
Autores y matriculas:
-Salvador Alejandro Gaytán Ibáñez A01730311
-Victor Alfonso Mancera Osorio A01733749

Fecha de creacion:08/10/2020
Ultima modificaion:11/10/2020
*/

#include <bits/stdc++.h>
#include <iostream>
#include <iomanip>
#include <map>
#include <string>
#include <vector>
using namespace std;


//Objeto petición que se encarga de almacena en propiedades separadas cada uno de los
//valores inmersos en  las notificaciones de la bitacora
class Peticion {
private:
//Separamos entonces los meses, dias, horas, la ip  y el mensaje
    std::string mes;
    std::string dia;
    std::string hora;
    std::string ip;
    std::string mensaje;


    //Creamos un diccionario para poder relacionar el mes con su respectivo número
    std::map<std::string, std::string> clavesMes =
            {{"Jan", "01"}, {"Feb", "02"},  {"Mar", "03"},  {"Apr", "04"},  {"May", "05"},  {"Jun", "06"},  {"Jul", "07"},  {"Aug", "08"}, {"Sep", "09"}, {"Oct", "10"}, {"Nov", "11"}, {"Dec", "12"}};


public:
    vector<int> ipNumeros;

//Establecemos los constructores
    explicit Peticion();
    explicit Peticion(std::string Umes, std::string Udia, std::string Uhora, std::string Uip, std::string Umensaje );

//Función que transformará toda la fecha en unidad unix
    long int obtenerUnit();

//Métodos que imprimen los valores más relevantes
    void imprimir();
    std::string imprimirarchivo();

    void separarNumerosIp();

//Métoodo que se encarga de regresar el dia junto con el mes de la petición
    std::string diaMes();


};

Peticion::Peticion(): mes("1"), dia("1"), hora("00:00:00"), ip(""), mensaje("Ningnuno"){};
Peticion::Peticion(std::string Umes, std::string Udia, std::string Uhora, std::string Uip, std::string Umensaje ): mes(Umes), dia(Udia), hora(Uhora), ip(Uip), mensaje(Umensaje){};


void Peticion::imprimir(){
    std::string texto = mes + " " + dia + " " + hora + " " + ip + " " + mensaje;

    std::cout<<texto<<"\n" ;
}
std::string Peticion::imprimirarchivo(){
    std::string texto = mes + " " + dia + " " + hora + " " + ip + " " + mensaje+"\n";

    return texto;
}

std::string Peticion::diaMes() {

    std::string valor = mes + " " + dia;

    return valor;
}

//Para transfomrar a unidad de tiempo "Unix" realizamos el siguiente método
long int Peticion::obtenerUnit(){
    std::tm t = {};
    //Establecemos el formato de la fecha, en donde por cuestiones de eficiencia,
    //establecemos el año como 1970 (Año en donde empeiza el conteo numérico)
    std::string fecha = "1970-"+clavesMes[mes]+"-"+dia+"T"+hora+"Z"; //Original "1970-11-04T23:23:01Z"

    //Creamos un stringstream que almacenara cada elemento de la fecha
    std::istringstream ss(fecha);
    long int valor;
    //Si cada elemento corresponde al formato año, mes dia hora minuto y segundo
    if (ss >> std::get_time(&t, "%Y-%m-%dT%H:%M:%S"))
    {
        //Regresamos el valor numerico haciendo uso de "mktime"
        return valor = std::mktime(&t);
    }
        //En caso de que ese no sea el formato, entonces...
    else
    {
        std::cout << "Formato inválido\n";
    }
    return 0;
}


//Método que se encarga de separar los numeros que conforman la ip con la finalidad de comparalos con otras ip's
void Peticion::separarNumerosIp(){
    string parteIp =" "; //Establecemos un string que almacenrá cada parte de la ip
    //COMPLEJIDAD: O(c) donde c es el numero de caracteres en la IP
    for(char& c : ip) { //Recorremos cada caracter del string
        if(c != ':' && c != '.' ){ //Si no encontramos : o .
            parteIp+=c; //Entonces añadimos ese caracter a nuestro "parteIp"
        }
            //En caso de que encontremos un punto o :
        else{
            //Añadimos a nuestro vector el numero que logramos conformar
            ipNumeros.push_back(stoi(parteIp));
            //Reestablecemos nuestra variable que almacena las partes de la ip
            parteIp = "";
        }
    }
    //Finalmete, añadimos la ultima parte de la ip
    ipNumeros.push_back(stoi(parteIp));
}






//Clase nodo 
class Node
{
//Atributos públicos
public:
    Peticion data; //La Petición que almacena
    Node *next, *prev; //Los punteros al nodo anterior y siguiente
};

//Declaramos que existirá una función que separa los nodos
Node *split(Node *head);

// Función que se encarga de unir dos listas
Node *merge(Node *first, Node *second)
{
    // Si la primera lista está vacía
    if (!first)
        return second; //Regresa la segunda

    // Si la segunda lista está vacía...
    if (!second)
        return first; //Regresa la primera

    // Si el primer numero de la ip es menor al de la segunda lista...
    if (first->data.ipNumeros[0] < second->data.ipNumeros[0])
    {
      //Aplicamos merge al siguiente elemento de la primera lista, brindandole el mismo elemento de la segunda lista
        first->next = merge(first->next,second);
        //Establecemos que el previo al siguiente nodo será first
        first->next->prev = first;
        //Y el previo a first será nulo 
        first->prev = NULL;
        //Regresamos first
        return first;
    }
    //De cualquier otra forma...
    else
    { 
        //Establecemos dos banderas
        bool compararTiempo = false;
        bool segundoMenor = false;
        //Establecemos un índice que compara todos los elementos de la ip
        int indiceNumero = 0;
        //Mientras los datos de ambos números sea iguales...
        while (first->data.ipNumeros[indiceNumero] == second->data.ipNumeros[indiceNumero]){
            //Aumentamos el indiceNumero
            indiceNumero++;
            //Si el indiceNumero es igual aol tamaño del vector...
            if(indiceNumero == first->data.ipNumeros.size() || indiceNumero == second->data.ipNumeros.size()){
                //Se establece que entonces ambos tienen la misma ip, y por ende, procedemos a compararTiempo
                compararTiempo = true;
                //Rompemos el gadget
                break;
            }
        }
      
        //Si comparar tiempo es igual
        if(compararTiempo){
            //Comparamos el tiempo de ambos...
            //... si el tiempo del primero es mayor que el segundo...
            if(first->data.obtenerUnit() > second->data.obtenerUnit()){
                //Establecemos que el segundo es menor
                segundoMenor = true;
            }
        }

      //Si el dato de la primera lista es menor, o comparar tiempo fue verdadero y el segundo no fue menor...
        if((first->data.ipNumeros[indiceNumero] < second->data.ipNumeros[indiceNumero]) || (compararTiempo && !segundoMenor)){
            //Realizamos el mismo procedimiento que arriba
            first->next = merge(first->next,second);
            first->next->prev = first;
            first->prev = NULL;
            return first;
        }
        
        //De lo contrario (En el caso de que la lista dos sea menor)
        else{
            //Establecemos que su siguiente elemento será la mezcla entre el primer elemento y el siguiente elemento en cuestión
            second->next = merge(first,second->next);
            //Establecemos que su previo será el elemento actual
            second->next->prev = second;
            //Y el elemento actual su previo será nulo
            second->prev = NULL;
            //Lo regresamos
            return second;
        }

    }
}

// Función que ejecuta el merge (COMPLEJIDAD: O(nlogn)
Node *mergeSort(Node *head) //Toma la cabeza como argumento
{
    if (!head || !head->next) //Checa que la lista no esté vacía 
        return head;
    
    Node *second = split(head); //Partimos la lista en dos

    //Aplicamos recursión para ambas partes de la lista
    head = mergeSort(head);
    second = mergeSort(second);

    // Al final las unimos con el merge
    return merge(head,second);
}

//Método que se encarga de insertar
void insert(Node **head, Peticion data)
{
    Node *temp = new Node(); //Creamos un nuevo nodo que es temporal
    temp->data = data; //Te doy tu data
    temp->next = temp->prev = NULL; //Ambas direcciones son nulas
    if (!(*head)) //Si no hay head...
        (*head) = temp; //Entonces el dato que entro ahora es temporal
    else //Una vez que ya exista un dato
    {
        temp->next = *head; //El siguiente será head
        (*head)->prev = temp;  //El previo de head será temporal 
        (*head) = temp; //Temporal será la cabeza
    }
    //Esto nos permite añadir al incio (Complejidad O(1))
 }

//Función que nos permite imprimir todos los nodos
void print(Node *head)
{
    // se crea el txt
    string verout;
    verout="sortedData.txt";
    ofstream archivosalida(verout);
    //Nodo temporal que nos permite desplazarnos en la lista
    Node *temp = head;
    //Nodo que almacena el ultimo
    Node *final = NULL;
    //Nos desplazamos en la lista
    while (head) //COMPLEJIDAD (O(n))
    {   
        temp = head;
        head = head->next;             
    }


    while (temp) //COMPLEJIDAD (O(n))
    {        
        if(temp->prev == NULL){
          head = temp;      
        }
        temp = temp->prev;
    }

     while (head) //COMPLEJIDAD (O(n))
    {   
      //se exportan los datos al txt
        archivosalida<<head->data.imprimirarchivo(); 
        temp = head;
        head = head->next;             
    }




}
vector<int> separarNumeros(string ip){
  vector<int> ipNumeros;
  string parteIp =" "; //Establecemos un string que almacenrá cada parte de la ip
    //COMPLEJIDAD: O(c) donde c es el numero de caracteres en la IP
    for(char& c : ip) { //Recorremos cada caracter del string
        if(c != ':' && c != '.' ){ //Si no encontramos : o .
            parteIp+=c; //Entonces añadimos ese caracter a nuestro "parteIp"
        }
            //En caso de que encontremos un punto o :
        else{
            //Añadimos a nuestro vector el numero que logramos conformar
            ipNumeros.push_back(stoi(parteIp));
            //Reestablecemos nuestra variable que almacena las partes de la ip
            parteIp = "";
        }
    }
    //Finalmete, añadimos la ultima parte de la ip
    ipNumeros.push_back(stoi(parteIp));
    //Lo regresamos
    return ipNumeros;   
}
void busqueda(Node *head,vector<int> Inicio, vector<int> Fin){//Algoritmo de busqueda, O(5n)
  Node *temp;
  temp=head;
  bool bandera;
  while (head){ //se alcanza el ultimo elemento de la lista  
      temp = head;
      head = head->next;             
  }

  while(temp){//ciclo que recorre desde el ultimo elemento de la lista hasta el primero
  //de manera que se impriman en orden descendente
    bool imprimir = false;// bandera que indica si ese elemento de la lista se imprime o no
    int i = 0;
    bool igualMenor = false;
    bool igualMayor= false;

    while(true){//ciclo que verifica que la ip del nodo sea mayor o igual que la ip de inicio y mmenor o igual a la ip final.

      //condicional que revisa que el dato este entre los valores de inicio y fin
      if(temp->data.ipNumeros[i] > Inicio[i] && temp->data.ipNumeros[i] < Fin[i] ){       
        imprimir = true;
        break; 
      }
      //condicional que revisa que la primer posicion de ip del objeto peticion sea igual al primer elemento de floor
      else if(temp->data.ipNumeros[i] == Inicio[i] || temp->data.ipNumeros[i] == Fin[i]){
        if(temp->data.ipNumeros[i] == Inicio[i] && i == 0){
          igualMenor = true; 
        }
        //condicional que revisa que el numero del ip en la primer posicion sea igual a fin en la primer posicion
        if(temp->data.ipNumeros[i] == Fin[i] && i == 0){
          igualMayor = true;
        }
        i++;
        // condicional que comprueba que la ip sea igual al inicio o al final
        if(i == 5){
          imprimir = true;
          break;
        }
      }
      //en caso que el valor actual y los anteriores  de la ip sea igual a los de el inicio o los del fin 
      else if (i>=1){
        if(igualMayor && igualMenor) {// revisa si el valor recorrido hasta ahora es igual al del inicio y al del final
          if(temp->data.ipNumeros[i]>Inicio[i] && temp->data.ipNumeros[i] < Fin[i]){//misma condicional para imprimir si es un valor intermedio de inicio o fin
            imprimir = true;
          }
        }
        
        else if(igualMenor &&temp->data.ipNumeros[i]>Inicio[i] ){//revisa que igualMenor sea true y que ademas que el valor sea mayor a el valor de inicio en posicion i
          imprimir =true;                      
          
        }
                
        else if(!igualMenor && temp->data.ipNumeros[i] < Fin[i]){// misma condicional que el anterior pero para el final
          imprimir =true;                      
          
        }      
        break;                
      }
      
      else{//si no se cumple nada, break
        break;
      }
    }
    if(imprimir){//en caso de que se haya vuelto true imprimir
      temp->data.imprimir();//se imprime el nodo
    } 
    temp=temp->prev;//se recorre la lista del ultimo valor hasta el primero                   
  }               
}



// Separa la lista en dos distintas
Node *split(Node *head)
{
    //Nodo que recorre la lista de forma rapida y otro lenta
    Node *fast = head,*slow = head;
    //Mientras fast encuentre un nodo, adelante de él y dos adelante
    while (fast->next && fast->next->next)
    {
        //Fast recorre el doble de rápido la lista 
        fast = fast->next->next;
        //Y slow se queda a la mitad cuando fast no posee elementos
        slow = slow->next;
    }
    //Almacenamos la ubicación en temporal
    Node *temp = slow->next;
    //Accedo a slow, y le digo que next será nulo
    slow->next = NULL;
    //Regreso temp
    return temp;
}


//Metodo que se encarga de leer los datos por parte del txr
void lecturaDatos(){
    Node *raiz = NULL; //Establecemos un nodo raiz

    //Creamos el objeto del archivo a arbitraria
    ifstream archivo;
    //Generamos un vector de objetos peticiones
    vector<Peticion> misPeticiones;
    //Abrimos el archivo de nombre "bitácota.txt"
    archivo.open("bitacora.txt");
    //Si el archivo se encuentra abierto...
    if(archivo.is_open()){
        //Creamos una variable que alamcenara cada lista
        std::string linea;
        //Ejecutamos un ciclo que recorre todas las lineas del archivo
        while (getline(archivo, linea)){
            //Por cada linea, creamos un "separador" de tipo "stringstream"
            std::stringstream separador(linea);
            //Creamos una variable que alamcenará cada palabra
            std::string palabra;
            //Un vector de palabras separadas de cada línea
            vector<string> palabras;
            //Indice que indica el numero de palabra que estamos analizando
            int indice = 0;

            //Ciclo que recorre cada una de las palabras
            while(separador >> palabra){
                //Si el indice es igual o mayor a 5, significa que estamos en el mensaje de error
                if(indice >= 5){
                    //Lo anexamos en el indice 4
                    palabras[indice-1] += " " + palabra;
                }
                    //De cualquier otra forma, significa que estamos en las palabras anteriores
                else{
                    //Las añadimo al vector y aumentamos el indidce para que siga almacenando las palabras en espacios distintos del vector.
                    palabras.push_back(palabra);
                    indice++;
                }
            }

            //Creamos el objeto peticion, brindando como argumentos cada elemento de mi vector de palabras
            auto objeto = Peticion(palabras[0], palabras[1], palabras[2], palabras[3], palabras[4]);
            //Ejecutamos el método que se encarga de separar los números de la ip
            objeto.separarNumerosIp();
            //Añadimos nuestro objeto al arreglo de peticiones
            misPeticiones.push_back(objeto);

            insert(&raiz, objeto);

        }
        //Los ordenamos a través de sort
        mergeSort(raiz);
        print(raiz);
        
        string DatoInicio;
        string DatoFin;
        cin>>DatoInicio;
        cin>>DatoFin;        
        
        vector<int>numerosInicio;
        numerosInicio=separarNumeros(DatoInicio);
        
        
        vector<int>numerosFin;   
        numerosFin = separarNumeros(DatoFin);
        
        busqueda(raiz,numerosInicio,numerosFin);



        

    }
    else {
        std::cout<<"Error! No se pudo abrir el archivo";
    }
}




int main() {
    //ejecucion del metodo principal del programa
    lecturaDatos();


    return 0;
}
