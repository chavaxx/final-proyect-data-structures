//Salvador Alejandro Gaytán Ibáñez   A01730311
//Victor Alfonzo Mancera Osorio   A01733749
//Daniel Munive Meneses A01734205 
#include <iostream>
#include <queue>
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <algorithm>
#include <bits/stdc++.h>
#include <iomanip>

using namespace std;



//Objeto petición que se encarga de almacena en propiedades separadas cada uno de los
//valores inmersos en  las notificaciones de la bitacora
class Peticion {
private:
//Separamos entonces los meses, dias, horas, la ip  y el mensaje
    std::string mes;
    std::string dia;
    std::string hora;
    std::string ip;
    std::string mensaje;


    //Creamos un diccionario para poder relacionar el mes con su respectivo número
    std::map<std::string, std::string> clavesMes = {{"Jan", "01"}, {"Feb", "02"},  {"Mar", "03"},  {"Apr", "04"},  {"May", "05"},  {"Jun", "06"},  {"Jul", "07"},  {"Aug", "08"}, {"Sep", "09"}, {"Oct", "10"}, {"Nov", "11"}, {"Dec", "12"}};


public:
    vector<string> ipNumeros;

//Establecemos los constructores
    explicit Peticion();
    explicit Peticion(std::string Umes, std::string Udia, std::string Uhora, std::string Uip, std::string Umensaje );

//Función que transformará toda la fecha en unidad unix
    long int obtenerUnit();

//Métodos que imprimen los valores más relevantes
    void imprimir();
    std::string imprimirarchivo();

    void separarNumerosIp();

//Métoodo que se encarga de regresar el dia junto con el mes de la petición
    std::string diaMes();


    string ObtenerElementoIP(string opcion);
};

Peticion::Peticion(): mes("1"), dia("1"), hora("00:00:00"), ip(""), mensaje("Ningnuno"){};
Peticion::Peticion(std::string Umes, std::string Udia, std::string Uhora, std::string Uip, std::string Umensaje ): mes(Umes), dia(Udia), hora(Uhora), ip(Uip), mensaje(Umensaje){};


void Peticion::imprimir(){
    std::string texto = mes + " " + dia + " " + hora + " " + ip + " " + mensaje;

    std::cout<<texto<<"\n" ;
}
std::string Peticion::imprimirarchivo(){
    std::string texto = mes + " " + dia + " " + hora + " " + ip + " " + mensaje+"\n";

    return texto;
}

std::string Peticion::diaMes() {

    std::string valor = mes + " " + dia;

    return valor;
}

//Para transfomrar a unidad de tiempo "Unix" realizamos el siguiente método
long int Peticion::obtenerUnit(){
    std::tm t = {};
    //Establecemos el formato de la fecha, en donde por cuestiones de eficiencia,
    //establecemos el año como 1970 (Año en donde empeiza el conteo numérico)
    std::string fecha = "1970-"+clavesMes[mes]+"-"+dia+"T"+hora+"Z"; //Original "1970-11-04T23:23:01Z"

    //Creamos un stringstream que almacenara cada elemento de la fecha
    std::istringstream ss(fecha);
    long int valor;
    //Si cada elemento corresponde al formato año, mes dia hora minuto y segundo
    if (ss >> std::get_time(&t, "%Y-%m-%dT%H:%M:%S"))
    {
        //Regresamos el valor numerico haciendo uso de "mktime"
        return valor = std::mktime(&t);
    }
        //En caso de que ese no sea el formato, entonces...
    else
    {
        std::cout << "Formato inválido\n";
    }
    return 0;
}


//Método que se encarga de separar los numeros que conforman la ip con la finalidad de comparalos con otras ip's
void Peticion::separarNumerosIp(){
    string parteIp =""; //Establecemos un string que almacenrá cada parte de la ip
    //COMPLEJIDAD: O(c) donde c es el numero de caracteres en la IP
    for(char& c : ip) { //Recorremos cada caracter del string
        if(c != '.' && c != ':' ){ //Si no encontramos : o .
            parteIp+=c; //Entonces añadimos ese caracter a nuestro "parteIp"
        }
            //En caso de que encontremos un punto o :
        else{
            //Añadimos a nuestro vector el numero que logramos conformar
            ipNumeros.push_back(parteIp);
            //Reestablecemos nuestra variable que almacena las partes de la ip
            parteIp = "";
        }
    }
    //Finalmete, añadimos la ultima parte de la ip
    ipNumeros.push_back(parteIp);
}

string Peticion::ObtenerElementoIP(string opcion){
    separarNumerosIp();
    string valorCompleto = "";
    if(opcion == "red"){
        valorCompleto = ipNumeros[0]+".";
        valorCompleto += ipNumeros[1];
    }
    else{
        valorCompleto = ipNumeros[2]+".";
        valorCompleto += ipNumeros[3];

    }

    return valorCompleto;
}




//Clase destinada a crear nodos que representen el camino
class NodoHost {
public:
    //Poseen un valor
    string valor;
    //Un puntero al siguiiente nodo
    NodoHost* nodoSiguiente;

    //Vector con todos los mensajes de error de este registro
    vector<string>misMensajes;

    //Constructor
    NodoHost(string nuevoValor){
        valor = nuevoValor;
        nodoSiguiente = nullptr;
    }

    NodoHost(){
        valor = "";
        nodoSiguiente = nullptr;
    }

    void addMensaje(string mensaje){
        misMensajes.push_back(mensaje);
    }


    void imprimirMensajes(){
        cout<<"     ***********"<<endl;
        cout<<"Maximo ocurrencias: "<<misMensajes.size()<<endl;
        for(string mensaje : misMensajes){
            cout<<"      "<<mensaje<<endl;
        }
        cout<<"     ***********"<<endl;

    }
};


//Nodo cabeza o base del cual se parte del camino (NodoAzul)
class NodoRed{
public:
    //Posee un valor
    string valor;
    //Un nodo rojo inicial
    NodoHost* nodoRojo;
    //Un nodo azul con el que se comunica con el resto de nodos
    NodoRed* nodoAzul;

    //Constructor
    NodoRed(string miValor, NodoHost* miNodoCamino, NodoRed* miNodoBase){
        valor = miValor;
        nodoRojo = miNodoCamino;
        nodoAzul = miNodoBase;
    }

    NodoRed(){
        valor = "";
        nodoRojo = nullptr;
        nodoAzul = nullptr;
    }

    //Método que se encarga de añadir un nodo rojo.
    void addNodoRojo(NodoHost* nuevoNodo, string mensaje){
        bool repetido = false;
        //Si se posee un nodo rojo
        if(nodoRojo != nullptr){
            //Los recorremos
            NodoHost* nodoActual = nodoRojo;
            if(nodoActual->valor == nuevoNodo->valor){
                repetido = true;
            }
            while(nodoActual->nodoSiguiente != nullptr){
                if(nodoActual->valor != nuevoNodo->valor){
                    nodoActual = nodoActual->nodoSiguiente;
                }
                else{
                    repetido = true;
                    break;
                }
            }
            //Una vez que llegamos al último, establecemos que su siguiente nodo será el nuevo nodo

            if(!repetido){
                nodoActual->nodoSiguiente = nuevoNodo;
            }
            else{
                nodoActual->addMensaje(mensaje);
            }

        }
            //En caso de que no tengamos alguno, decimos que el nodo rojo base de este nodo azul, será el nuevo nodo
        else{
            nodoRojo = nuevoNodo;
        }

    }

    void addNodoAzul(NodoRed* nodoBase){
        nodoAzul = nodoBase;
    }

    int obtenerGrado(){
       int grado = 0;
       NodoHost* nodoActual = nodoRojo;
       while (nodoActual != nullptr){
           grado++;
           nodoActual = nodoActual->nodoSiguiente;
       }

       return grado;
    }

    //Complejidad O(n)
    //Busca el Grado mayor
    int maxRed(){
      NodoHost* nodoActual = nodoRojo;
      int gradoMax=0;
      int grd=0;
      if(nodoActual == nullptr){
          cout<<" FIN "<<endl;
      }
      else{
         grd=obtenerGrado();
         if (grd > gradoMax){
           gradoMax = grd;
         } else {
           gradoMax = gradoMax;
         }
      }
      return gradoMax;
    }

    //Complejidad O(n)
    //Imprime el valor Red que cumpla con el grado maximo
    void imprimirMaxRed(int gradoMax){
      NodoHost* nodoMax = nodoRojo;

      if(nodoMax == nullptr){
          cout<<" "<<valor<<endl;
      }
      else{
        if (obtenerGrado() == gradoMax) {
          cout<<valor<<endl;
        }
      }

      while(nodoMax != nullptr){

          nodoMax = nodoMax->nodoSiguiente;
      }

    }

};


//Metodo que se encarga de leer los datos por parte del txr
void lecturaDatos(){

    NodoRed* nodoRaiz = new NodoRed();
    //Creamos el objeto del archivo a arbitraria
    ifstream archivo;
    //Generamos un vector de objetos peticiones
    vector<Peticion> misPeticiones;
    //Abrimos el archivo de nombre "bitácota.txt"
    archivo.open("bitacora2.txt");
    //Si el archivo se encuentra abierto...
    if(archivo.is_open()){
        //Creamos una variable que alamcenara cada lista
        std::string linea;
        //Ejecutamos un ciclo que recorre todas las lineas del archivo
        while (getline(archivo, linea)){
            //Por cada linea, creamos un "separador" de tipo "stringstream"
            std::stringstream separador(linea);
            //Creamos una variable que alamcenará cada palabra
            std::string palabra;
            //Un vector de palabras separadas de cada línea
            vector<string> palabras;
            //Indice que indica el numero de palabra que estamos analizando
            int indice = 0;

            //Ciclo que recorre cada una de las palabras
            while(separador >> palabra){
                //Si el indice es igual o mayor a 5, significa que estamos en el mensaje de error
                if(indice >= 5){
                    //Lo anexamos en el indice 4
                    palabras[indice-1] += " " + palabra;
                }
                    //De cualquier otra forma, significa que estamos en las palabras anteriores
                else{
                    //Las añadimo al vector y aumentamos el indidce para que siga almacenando las palabras en espacios distintos del vector.
                    palabras.push_back(palabra);
                    indice++;
                }
            }

            //Creamos el objeto peticion, brindando como argumentos cada elemento de mi vector de palabras
            auto objeto = Peticion(palabras[0], palabras[1], palabras[2], palabras[3], palabras[4]);

            //Obtengo los dos enteros del host
            string valorHost = objeto.ObtenerElementoIP("host");
            //Creo un objeto nuevo de tipo nodoHost
            NodoHost* nuevoNodoHost = new NodoHost(valorHost);
            //le asigno el mensaje en cuestión
            nuevoNodoHost->addMensaje(palabras[4]);

            //Si el nodo raiz no tiene nada...
            if(nodoRaiz->valor == ""){
                //Creo un nuevo nodo red
                NodoRed* nuevoNodoRed = new NodoRed(objeto.ObtenerElementoIP("red"), nuevoNodoHost, nullptr );
                //Establezco que el nodo raiz sera el nuevo nodo red
                nodoRaiz = nuevoNodoRed;
            }
            //Si mi raiz no está vacía
            else{
                //Obtengo los dos enteros de la red
                string valorRed =  objeto.ObtenerElementoIP("red");
                //Establezco una bandera que me avisará si el valor de este nodo ya se encuentra en la lista
                bool nodoEnLista = false;

                //Obtengo el nodo actual
                NodoRed* nodoActual = nodoRaiz;
                //Recorro todos los nodos (COMPLEJIDAD: O(n))
                while(nodoActual->nodoAzul != nullptr){
                    //Si algun nodo ya posee el valor del nuevo nodo...
                    if(nodoActual->valor == valorRed){
                        //A ese nodo (Al de la lista) le añado su nodo rojo
                        nodoActual->addNodoRojo(nuevoNodoHost, palabras[4]);
                        //Establezco que está en la lista
                        nodoEnLista = true;
                    }
                    //De lo contrario, seguimos recorriendo
                    nodoActual = nodoActual->nodoAzul;
                }


                //Si el nodo noe estaba en la lista
                if(nodoEnLista == false){
                    //Verificamos de nueva cuenta que el nodo no sea igual al valor
                    if(nodoActual->valor == valorRed){
                        //Si el nodo actual tiene el mismo valor, entonces a ese nodo le añado su nodo rojo
                        nodoActual->addNodoRojo(nuevoNodoHost, palabras[4]);
                    }
                    else{ //Si el nodo de la lista no es el mismo...
                        //Creo el nuevo nodo red
                        NodoRed* nuevoNodoRed = new NodoRed(objeto.ObtenerElementoIP("red"), nuevoNodoHost, nullptr );
                        //Lo añado a los azules
                        nodoActual->addNodoAzul(nuevoNodoRed);
                    }

                }

            }

            //Añadimos nuestro objeto al arreglo de peticiones
            misPeticiones.push_back(objeto);



        }
    }
    else {
        std::cout<<"Error! No se pudo abrir el archivo";
    }
    NodoRed* NodoActual;
    NodoActual = nodoRaiz;
    int maxGrd = 0;
    int grd = 0;
    while (NodoActual != nullptr){
        grd = NodoActual->maxRed();
       if (grd> maxGrd) {
         maxGrd=grd;
       } else {
         maxGrd=maxGrd;
       }
        NodoActual = NodoActual->nodoAzul;
    }

    NodoActual = nodoRaiz;

      while (NodoActual != nullptr){
          NodoActual->imprimirMaxRed(maxGrd);
         NodoActual = NodoActual->nodoAzul;
      }
      std::cout << endl;

    // se reinicializan los valores
    NodoActual=nodoRaiz;
    NodoHost* NodoNext= NodoActual->nodoRojo;
    int maxOcurrencias=0;// int que contiene el maximo de ocurrencias de los nodos
    while(NodoActual != nullptr){ // ciclo de orden O(n²) que busca el maximo de ocurrencias
      while(NodoNext != nullptr){//ciclo que recorre los nodos hijo de cada uno de los nodos padre buscando 
        if(NodoNext->misMensajes.size()>maxOcurrencias){//si encuentra un nodo con una ocurrencia mayor a la maxima ocurrencia actual
          maxOcurrencias=NodoNext->misMensajes.size();//actualiza la maxima ocurrencia
        }
        NodoNext=NodoNext->nodoSiguiente;//se mueve en nodos hijo
      }
      NodoActual=NodoActual->nodoAzul;//se mueve en nodos padre
      if(NodoActual!= nullptr){//si el nodo padre no es null, asigna en nodo hijo correspondiente
        NodoNext=NodoActual->nodoRojo;
      }

    }
    //se regresan los nodos a las condiciones iniciales
    NodoActual=nodoRaiz;
    NodoNext= NodoActual->nodoRojo;
    while(NodoActual != nullptr){//se vuelve a recorrer toda la estructura pero ahora buscando los valores, O(n²)
     while(NodoNext != nullptr){//recorre los nodos hijo
       if(NodoNext->misMensajes.size()==maxOcurrencias){//si encuentra un nodo con ocurrencia igual a la ocurrencia maxima
         cout<<NodoActual->valor<<"."<<NodoNext->valor<<endl;//lo imprime
       }
       NodoNext=NodoNext->nodoSiguiente;//se mueve en los nodos hijo
     }
     NodoActual=NodoActual->nodoAzul;//se mueve en los nodos padre
     if(NodoActual != nullptr){//si NodoActual no es nullptr (se acabo el grafo)
       NodoNext=NodoActual->nodoRojo;//asigna el valor al nodo hijo
     }
    }
};


int main() {

    lecturaDatos();

}

